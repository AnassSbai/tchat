<?php
#@author Anass SBAI SASSI <sbaianass@gmail.com>
final class DBConnexion_Model{
	/**
	 * @var DBConnexion_Model
	 * @access private
	 * @static
	 */
	private static $_instance = null;
	private static $connexion;
	
	/**
	 * Constructeur de la classe
	 * 
	 * Fonction utilise dans l'etablissement de la connexion avec la base de donnees 
	 */
	private function __construct(){
		try{
		 	self::$connexion = new PDO(_DSN, _BASE_USER, _BASE_PASSWORD);  		
		 }catch(PDOException $e){
			die('Connection failed: ' . $e->getMessage());
		 }  
	}
			
	/**
	 * Methode qui cree l'unique instance de la classe
	 *
	 * @param void
	 * @return DBConnexion_Model
	 */
	public static function getInstance(){
		if(is_null(self::$_instance)){
			self::$_instance = new DBConnexion_Model();
		}
		return self::$_instance;
	}
	
	/**
	 * Fonction util pour le relancement de requete de mise A jour(ajout, modification et suppression)
	 *
	 * @param string $query
	 */
	public static function __sendUpdateQuery($query){
		try{
		   self::$connexion->beginTransaction();
		   self::$connexion->query($query); 
		   self::$connexion->commit(); 
		}catch(PDOException $e){
			self::$connexion->rollBack(); 
			die('Connection failed: ' . $e->getMessage());
		}
	}
	
	/**
	 * Fonction util pour le relancement de requete de selection (Ensemble d'enregistrement)
	 *
	 * @param string $query
	 * @return array
	 */
	public static function __receiveResultQuery($query){
		try{
			$resultats = self::$connexion->query($query);
			return $resultats->fetchAll(PDO::FETCH_OBJ);
		}catch(PDOException $e){
			die('Connection failed: ' . $e->getMessage());
		}		  
	} 
	
	/**
	 * Fonction util pour le relancement de requete de selection (Un seul enregistrement)
	 *
	 * @param string $query
	 * @return stdclass
	 */ 
	public static function __receiveOneResultQuery($query){
		try{		
			$resultat = self::$connexion->query($query);
			return $resultat->fetch(PDO::FETCH_OBJ);			
		}catch(PDOException $e){
			die('Connection failed: ' . $e->getMessage());
		}		
	} 
}
?>
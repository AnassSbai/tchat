<?php
#@author Anass SBAI SASSI <sbaianass@gmail.com>
final class DefaultTchatController{	
	/**
	 * Constructeur de la classe
	 */
	public function __construct(){
		DBConnexion_Model::getInstance();   
	}

	/**
	 * Fonction permettant de retourner un numeric
	 *
	 * @param unknown_type $numero
	 */
	function getNumeric($numero){
		return ( (isset($numero)) && (!empty($numero)) ) ? $numero : 0;
	}
	
	/**
	 * Fonction de protection de la chaine
	 *
	 * @param unknown_type $data
	 */
	function filterData($data){
		return addslashes((strip_tags(trim($data))));
	}
		
	/**
	 * Fonction permettant de retourner la liste des utilisateurs
	 *
	 * @param unknown_type $current_user
	 * @return array
	 */
	public function getList_UsersAction($current_user){
		$query = 'SELECT id_utilisateur, prenom_utilisateur, nom_utilisateur FROM utilisateur WHERE id_utilisateur != '.$current_user;
		return DBConnexion_Model::__receiveResultQuery($query);
	}

	/**
	 * Fonction permettant de retourner la liste des utilisateurs
	 *
	 * @param unknown_type $current_user
	 * @return array
	 */
	public function getChat_MessagesUserAction($current_user, $another_user){
		$query = 'SELECT contenu_message, date_message, id_utilisateur_message_from
				  FROM message m
				  INNER JOIN utilisateur u ON u.id_utilisateur = m.id_utilisateur_message_from
				  WHERE id_utilisateur_message_from IN('.$current_user.','.$another_user.') AND 
				  		id_utilisateur_message_to IN('.$current_user.','.$another_user.')
				  ORDER BY date_message ASC';	
		return DBConnexion_Model::__receiveResultQuery($query);
	}	
	
	/**
	 * Fonction permettant d'ajouter un message
	 *
	 * @param unknown $user_from
	 * @param unknown $user_to
	 * @param unknown $message
	 */
	public function addNew_MessageUserAction($message, $user_from, $user_to){
		$query = 'INSERT INTO message(contenu_message, date_message, id_utilisateur_message_from, id_utilisateur_message_to) 
				  VALUES (\''.$this->filterData($message).'\', CURRENT_TIMESTAMP(), '.$user_from.', '.$user_to.')';
		return DBConnexion_Model::__sendUpdateQuery($query);
	}	
}
?>
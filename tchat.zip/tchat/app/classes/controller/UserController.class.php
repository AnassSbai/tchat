<?php 
#@author Anass SBAI SASSI <sbaianass@gmail.com>
final class UserController{
	/**
	 * Constructeur de la classe
	 */
	public function __construct(){
		DBConnexion_Model::getInstance();   
	}

	/**
	 * Fonction de protection de la chaine
	 *
	 * @param unknown_type $data
	 */
	function filterData($data){
		return addslashes((strip_tags(trim($data))));
	}
	
	/**
	 * Fonction permettant de vérifier l'accès à l'espace personnel (pour commencer le chat)
	 *
	 * @param unknown $login
	 * @param unknown $password
	 * @return stdclass
	 */
	public function isAuthorized_UserAction($login, $password){
		$query = 'SELECT * FROM utilisateur WHERE pseudo_utilisateur = \''.$this->filterData($login).'\' AND password_utilisateur = md5(\''.$password.'\')';
		return DBConnexion_Model::__receiveOneResultQuery($query);
	}
}
?>
<?php
#@author Anass SBAI SASSI <sbaianass@gmail.com>
final class SmartyTchat extends Smarty{
     public function __construct(){
     	parent::__construct();//Heritage de toutes les methodes de SMARTY
   		$this->template_dir = _ROOT_PATH.'view/smarty/templates/';//chemin absolu vers les templates
        $this->compile_dir = _ROOT_PATH.'view/smarty/templates_c/';//chemin absolu vers les templates geres par Smarty
        $this->config_dir = _ROOT_PATH.'view/smarty/configs/';//chemin absolu vers le repertoire de config de Smarty
        $this->cache_dir = _ROOT_PATH.'view/smarty/cache/';//chemin absolu vers le repertoire de cache de Smarty
        //Desactivation du cache - cote smarty
		$this->caching = false;//Pour ne pas avoir des problemes de cache / Affichage de la meme page web pendant une heure pour tout les utilisateur (c'est teste !)
		$this->force_compile = false;
		$this->compile_check = false;       
		//Chemin de librairie javascript
		$javascriptLibraries_path = '<script type=\'text/javascript\'>var _ROOT_URL=\''._ROOT_URL.'\';</script>';
		$javascriptLibraries_path .= '<script type=\'text/javascript\'>var _INCLUDE_AJAX_URL=\''._INCLUDE_AJAX_URL.'\';</script>';
        //Assignation des variables SMARTY
        $this->assign('_JS_LIBRARIES', $javascriptLibraries_path);
		$this->assign('_ROOT_URL', _ROOT_URL);
		$this->assign('_THIS_URL', _THIS_URL);
	}
}		
?>
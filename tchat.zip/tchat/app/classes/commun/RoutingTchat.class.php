<?php 
#@author Anass SBAI SASSI <sbaianass@gmail.com>
final class RoutingTchat{
	/**
	 * Constructeur de la classe
	 */
	public function __construct(){
	}
	
	/**
	 * Fonction de redirection
	 * 
	 * @param unknown $path
	 */
	public function generateUrl_Redirect($path){
		header('location:'.$path);
	}
}
?>
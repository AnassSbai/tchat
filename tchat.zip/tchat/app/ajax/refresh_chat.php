<?php
include rtrim($_SERVER['DOCUMENT_ROOT'], '/').'/tchat/app/config/params.inc.php';
$chat = new DefaultTchatController();
$id_selected_user = (isset($_POST['id_selected_user']) && !empty($_POST['id_selected_user'])) ? $chat->getNumeric($_POST['id_selected_user']) : 0;

if($id_selected_user == 0):
	echo '';
else:
	$chat_user = $chat->getChat_MessagesUserAction($_SESSION['id_utilisateur'], $id_selected_user);
	$title = '<h2>Chat</h2>';
	$chat_content = '';
	$i = 1;
	foreach($chat_user AS $chat):
		$style_css = ($i%2 == 0) ? 'background-color:#33ff93;' : 'background-color:#ffc433;';
		$identite = ($_SESSION['id_utilisateur'] == $chat->id_utilisateur_message_from) ? 'Moi' : 'Lui / Elle';
		$chat_content .= '<div class=\'content_chat\'>
							  <div>- <b>'.$identite.' :</b> '.$chat->date_message.'
								  <div class=\'clear\'/><div class=\'clear\'/>
								  	<span style=\''.$style_css.'\'>'.urldecode($chat->contenu_message).'</span>
								  </div>
								  <div class=\'clear\'/><br/>
							  </div>';
		$i++;
	endforeach;
	$form = '<form>
				<textarea name=\'new_message\' id=\'new_message\' cols=\'50\' rows=\'10\'></textarea>
				<div class=\'clear\'/><div class=\'clear\'/>
				<input type=\'button\' value=\'Envoyer\' id=\'send_message\' />
			</form>
			</div>';
	echo $title,$chat_content,$form;
endif;
?>
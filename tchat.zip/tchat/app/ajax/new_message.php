<?php
include rtrim($_SERVER['DOCUMENT_ROOT'], '/').'/tchat/app/config/params.inc.php';
$chat = new DefaultTchatController();

if(isset($_POST)):
	$message = $chat->filterData($_POST['nouveau_message']);
	$user_selected = $_POST['id_selected_user'];
	$chat->addNew_MessageUserAction($message, $_SESSION['id_utilisateur'], $user_selected);
endif;
?>
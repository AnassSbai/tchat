<?php
//Demarrage de session
session_start();

//Les directives 'php.ini
ini_set('error_reporting', E_ALL^E_NOTICE);
ini_set('display_errors', 'on');
ini_set('log_errors', 'on');

define('_ROOT_URL', 'http://'.$_SERVER['HTTP_HOST'].'/tchat/');
define('_THIS_URL', 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
define('_INCLUDE_AJAX_URL', _ROOT_URL.'app/ajax/');

//Definition des variables
define('_ROOT_PATH', rtrim($_SERVER['DOCUMENT_ROOT'], '/').'/tchat/');
define('_CLASSES_PATH', _ROOT_PATH.'app/classes/');

//Base de donn�es
define('_BASE_HOST', '127.0.0.1');
define('_DATABASE_NAME', 'tchat_db');
define('_BASE_USER', 'root');
define('_BASE_PASSWORD', '');
define('_BASE_CONNECT_PORT', '3306');	
define('_DSN', 'mysql:dbname='._DATABASE_NAME.';host='._BASE_HOST);

//Auto-charement des classes
function classe_Autoload_Commun($class_name){if(file_exists(_CLASSES_PATH.'commun/'.$class_name.'.class.php')) include _CLASSES_PATH.'commun/'.$class_name.'.class.php';}
function classe_Autoload_Controller($class_name){if(file_exists(_CLASSES_PATH.'controller/'.$class_name.'.class.php')) include _CLASSES_PATH.'controller/'.$class_name.'.class.php';}
function classe_Autoload_Model($class_name){if(file_exists(_CLASSES_PATH.'model/'.$class_name.'.class.php')) include _CLASSES_PATH.'model/'.$class_name.'.class.php';}
function classe_Autoload_Smarty($class_name){if(file_exists(_ROOT_PATH.'view/smarty/'.$class_name.'.class.php')) include _ROOT_PATH.'view/smarty/'.$class_name.'.class.php';}
spl_autoload_register('classe_Autoload_Commun');
spl_autoload_register('classe_Autoload_Controller');
spl_autoload_register('classe_Autoload_Model');
spl_autoload_register('classe_Autoload_Smarty');
?>
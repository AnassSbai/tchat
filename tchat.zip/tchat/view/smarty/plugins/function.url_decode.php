<?php
/**
 * Fonction permetant de decoder un lien pour l'adapter a l'url canonical (c'est le cas de la langue arabe)
 * 
 * @param unknown $params
 * @param unknown $smarty
 * @return string
 */
function smarty_function_url_decode($params, &$smarty){  
	return urldecode($params['Url']);
}
?>
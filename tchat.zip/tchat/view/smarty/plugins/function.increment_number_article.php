<?php
/**
 * Fonction de plugin util dans l'incrementation du nombre de visite d'un article (suivant l'id)
 * 
 * @param $params
 * @param $smarty
 */
function smarty_function_increment_number_article($params, &$smarty)
{
	$params['ARTICLE_OBJECT']->setNumberVisitorsArticle($params['ID_ARTICLE']);
}
?>

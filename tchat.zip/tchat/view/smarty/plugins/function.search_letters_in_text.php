<?php
/**
 * Fonction de plugin util pour rechercher une chaine de caractere dans un texte
 * 
 * @param $params
 * @param $smarty
 */
function smarty_function_search_letters_in_text($params, &$smarty)
{  
	$pos =  strpos($params['TEXT'], $params['SEARCH_LETTERS']);
	return (empty($pos)) ? -1 : $pos;
}
?>
<?php
/*%%SmartyHeaderCode:2292356feae8fb444f7_50505634%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a91f9ba0a93384f8850689b0c764fa646f3575dc' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\index.tpl',
      1 => 1455451919,
      2 => 'file',
    ),
    '9474ad554e096b19f20f1a79aa0d937b5a252c44' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\commun\\header.tpl',
      1 => 1458903833,
      2 => 'file',
    ),
    'ae9a15e0f3429457e4003a064a464d8927681c1f' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\commun\\header_bis.tpl',
      1 => 1458207544,
      2 => 'file',
    ),
    '9a2952a377b223d24987f6462b7812fa0c34e8db' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\publicite\\publicite_commune.tpl',
      1 => 1448906863,
      2 => 'file',
    ),
    '1c0a092e4fcd7a580ca921e4c36d8655e8972699' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\commun\\addtoany.tpl',
      1 => 1450603498,
      2 => 'file',
    ),
    '1be784ef01edfe3410ef29e8412b4a514d8153a0' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\publicite\\publicite_big_format.tpl',
      1 => 1449060646,
      2 => 'file',
    ),
    '23a50ac95d4023b9af994d4584a20ceb5b91fb7f' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\commun\\remarque_cookies.tpl',
      1 => 1449343988,
      2 => 'file',
    ),
    '38b80684f992db9c0fc25e9474a1b0cc3809c626' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\commun\\footer_bis.tpl',
      1 => 1455011090,
      2 => 'file',
    ),
    '7204d90564e49b4b1f3dae60f015d5d382058987' => 
    array (
      0 => 'D:\\wamp\\www\\career-news.blogger-link.com\\public\\smarty\\templates\\commun\\footer.tpl',
      1 => 1448708258,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2292356feae8fb444f7_50505634',
  'tpl_function' => 
  array (
  ),
  'variables' => 
  array (
    'contenu_article' => 0,
    '_PHOTO_URL' => 0,
    '_IMAGES_URL' => 0,
    'url_decode' => 0,
    'article' => 0,
    'TXT_FOOTER_LOGO_BLOGGER' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56feae9328e9b3_96174638',
  'cache_lifetime' => 3600,
),true);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56feae9328e9b3_96174638')) {
function content_56feae9328e9b3_96174638 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='utf-8'>	
	<meta name='viewport' content='width=device-width, initial-scale=1'>
	
	
			<title>2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse – blogger-link</title>
		
			<meta name='description' content="2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse – blogger-link" />
		
	<meta name='keywords' content='Jobs , internship offers , job applications , internship applications , entreprise recruitment , recruitment firm , job search , search internship , advice to pass the job interview , tips for passing the maintenance of training , tips for writing a CV, writing his CV, search for job announces , search job listings , search internship offers , research job applications , research internship demands , spend a job interview , an interview for internship , Blogger-Link.com, e-recruitment platform, job portal , electronic journal, jobs news , tips for writing a cover letter, write his cover letter.' />
	
			<meta name='abstract' content="2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse – blogger-link" />
		
	
	<meta name='category' content='Job search , good career advice' />	
	<meta name='subject' content='Job search , good career advice' />
	
	<meta name='robots' content='all, index, follow' />
	
					
	<link rel='canonical' href='https://fr.news.yahoo.com/bourse-renault-plonge-10-après-lannonce-perquisitions-110910766.html' />
	
			
	
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700|Montserrat+Subrayada:400,700|PT+Sans:400,400italic,700,700italic|PT+Sans+Narrow:400,700' rel='stylesheet' type='text/css' />
	<link rel='shortcut icon' href='https://localhost/career-news.blogger-link.com/public/media/images/favicon.ico' />
	
	<link rel='alternate' type='application/rss+xml' title="Rss feed - blogger-link.com" href='https://localhost/www.blogger-link.com/rss-feed/' />
	<link rel='alternate' type='application/atom+xml' title="Xml feed - blogger-link.com" href='https://localhost/www.blogger-link.com/xml-feed/' />
	
	<link rel='stylesheet' type='text/css' href='https://localhost/career-news.blogger-link.com/public/media/cache_combo_handler/combo_handler_css.php?css_files_gzip_deflate=D:/wamp/www/career-news.blogger-link.com/public/media/css/bootstrap.css|D:/wamp/www/career-news.blogger-link.com/public/media/css/commun.css|D:/wamp/www/career-news.blogger-link.com/public/media/css/jquery.mCustomScrollbar.css|D:/wamp/www/career-news.blogger-link.com/public/media/css/flexslider.css|D:/wamp/www/career-news.blogger-link.com/public/media/css/responsive.css'/>
</head>

<body >	
	<header>
	<div class='bandeHeader'>
		<div class='header'>
			<div class='blocLogo col-xs-12 col-sm-4'>
				
				<div class='logo'>
					<i class='img-ico-logo'></i>
					<div class='logoPage'><a href='https://localhost/www.blogger-link.com' title="blogger-link.com"><img src='https://localhost/career-news.blogger-link.com/public/media/images/logo.png' alt="blogger-link.com logo" /></a></div>
					<span class='pictoSaison'><a href='https://localhost/career-news.blogger-link.com' title='blogger-link.com! '><img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=59687451' alt='blogger-link.com! ' /></a></span>
					
																					<span class='payslg'>World!</span>
				</div>
				
								<div class='lang flecheCliquable'>
					<label title="English" class='libelle'>English</label>
					<span class='img-puce-lang'></span>
					<div class='blocLiens blocLangues'>
						<ul class='lang-selector__column'>
															<li class='lang-selector__option selected'> <a href='https://localhost/www.blogger-link.com/fr/' class='lang-selector__item ' title="French - Français">French - Français</a></li>
															<li class='lang-selector__option selected'> <a href='javascript:void(0);' class='lang-selector__item active' title="English">English<i class='img-ico-current'></i></a></li>
															<li class='lang-selector__option selected'> <a href='https://localhost/www.blogger-link.com/ar/' class='lang-selector__item ' title="Arabic - العربية">Arabic - العربية</a></li>
															<li class='lang-selector__option selected'> <a href='https://localhost/www.blogger-link.com/es/' class='lang-selector__item ' title="Spanish - español">Spanish - español</a></li>
													</ul>
						<div class='clear'></div>
					</div>
				</div>
				<div class='clear'></div>
							</div>
			<div class='blocProfil col-xs-12 col-sm-3'>
				
				<div class='profil flecheCliquable'>
					<label title="Profile - You"><img src='https://localhost/tofs.blogger-link.com/?type_photo=frontoffice-small-blogger-entreprise-bandeau&amp;url_image=https://localhost/tofs.blogger-link.com/original-photo.php?oid=59864894' alt="Profile - You" /></label>
					<span class='img-puce-lang pictoProfil'></span>
					<div class='blocLiens listeSimple'>
						
																								
						<a href="https://localhost/entreprise.blogger-link.com/19-blogger-link-ltd" class='lkn-services' title="Profile" target='_blank'><i class='img-ico-profil'></i>Profile</a>
													<a href='https://localhost/www.blogger-link.com/entreprise-space/' class='lkn-services' title="My account"><i class='img-ico-cmp'></i>My account</a>		
																									<a href='https://localhost/www.blogger-link.com/signout/' class='lkn-services' title="Signout"><i class='img-ico-decon'></i>Signout</a>
											</div>
					<div class='clear'></div>
				</div>
				
									<div class='messages flecheCliquable'>
						<span class='msg img-msg' title="It's Free !"></span>
						<span class='img-puce-lang pictoMsg'></span>
						<div class='blocLiens listeSimple'>
							<a href='https://localhost/www.blogger-link.com/entreprise-space/?action=new_job_offer_entreprise' title="Create a Job offer for Free !">A Job</a>
							<a href='https://localhost/www.blogger-link.com/entreprise-space/?action=new_training_offer_entreprise' title="Create a training offer for Free !">An Internship</a>
						</div>
					</div>				
								
				<div class='pays flecheCliquable'>
					<label><img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=59687449' alt="World" title="World"/></label>
					<span class='img-puce-lang pictoPays'></span>
					<div class='blocLiens blocPays'>
						<div class='content '>
							<h3 class='intl-sel-header fw-b fz-xs'>Select the site of a country</h3>							
														<div class='intl-sel-col d-ib col-xs-12 col-sm-3'>
								<h4 class='intl-sel-item fw-b fz-xs'>Internet<img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=59687450' alt="Internet" title="Internet" /></h4>
								<ul class='intl-sel-list'>
																	<li class='intl-sel-item'><a href='https://www.blogger-link.com' title="World" class='active'>World<i class='img-ico-current'></i></a></li>
																</ul>
							</div>
														<div class='intl-sel-col d-ib col-xs-12 col-sm-3'>
								<h4 class='intl-sel-item fw-b fz-xs'>Africa<img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=70314' alt="Africa" title="Africa" /></h4>
								<ul class='intl-sel-list'>
																	<li class='intl-sel-item'><a href='https://ma.blogger-link.com' title="Morocco" >Morocco</a></li>
																</ul>
							</div>
														<div class='intl-sel-col d-ib col-xs-12 col-sm-3'>
								<h4 class='intl-sel-item fw-b fz-xs'>Europe<img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=70338' alt="Europe" title="Europe" /></h4>
								<ul class='intl-sel-list'>
																	<li class='intl-sel-item'><a href='https://fr.blogger-link.com' title="France" >France</a></li>
																</ul>
							</div>
														<div class='intl-sel-col d-ib col-xs-12 col-sm-3'>
								<h4 class='intl-sel-item fw-b fz-xs'>Asia<img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=70339' alt="Asia" title="Asia" /></h4>
								<ul class='intl-sel-list'>
																	<li class='intl-sel-item'><a href='https://ae.blogger-link.com' title="United Arab Emirates" >United Arab Emirates</a></li>
																</ul>
							</div>
														<div class='intl-sel-col d-ib col-xs-12 col-sm-3'>
								<h4 class='intl-sel-item fw-b fz-xs'>America<img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=70340' alt="America" title="America" /></h4>
								<ul class='intl-sel-list'>
																	<li class='intl-sel-item'><a href='https://ca.blogger-link.com' title="Canada" >Canada</a></li>
																	<li class='intl-sel-item'><a href='https://us.blogger-link.com' title="United States" >United States</a></li>
																</ul>
							</div>
														<div class='intl-sel-col d-ib col-xs-12 col-sm-3'>
								<h4 class='intl-sel-item fw-b fz-xs'>Oceania<img src='https://localhost/tofs.blogger-link.com/original-photo.php?oid=70341' alt="Oceania" title="Oceania" /></h4>
								<ul class='intl-sel-list'>
																	<li class='intl-sel-item'><a href='https://au.blogger-link.com' title="Australia" >Australia</a></li>
																</ul>
							</div>
														
						</div>
					</div>
				</div>
				<div class='clear'></div>
			</div>
			
														
						
						
							<div class='blocBtn col-xs-12 col-sm-5'>
					<div class='bloggeur'>						
						<label title="Hi Anass Sbai Sassi">Hi Anass</label>
																			<a href="https://localhost/www.blogger-link.com/entreprise-space/" title="My account" class='btnVert'><i class='img-ico-cmp'></i>My account</a>
												<div class='clear'></div>
					</div>
				</div>
						<div class='clear'></div>
		</div>
	</div>
	</header>
	<section>
	
			<main><div id='blogger_header'><h3>2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse. On Blogger-Link.com.</h3></div></main>
		<div id='global'>
		
		
<section>
<div class='blocPub'>
	<div class="pub pub_occident">
		<img src='//lh5.ggpht.com/SzyuIRMEZCmj4eN4JnIwpMFwi-hWBkUMV8NmmXpQ5desFU6m1gw7RKtTuB8OgxnwEqX0sSiW=w895' />
	</div>
		<div class='pub-left'><img src='//lh4.ggpht.com/ike-jviZQ32RHuhkwLcAt_9vdpBX1oWKU00NX7QRe5GPl7-5sapzZ0u91_ssg_-Ednak2Hj-Hg=w162' /></div>
	</div>
</section>
				
		<div class='menu'>
			<button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#bs-example-navbar-collapse-1'>
				<span class='icon-bar'></span>
				<span class='icon-bar'></span>
				<span class='icon-bar'></span>
			</button>	
			<nav>			
			<ul class='menuPrincipal'>
				<li><a href='https://localhost/www.blogger-link.com' title="Home" class='home'><span>Home</span></a></li>
				<li><a href='javascript:void(0);' title="Offers & Applications&nbsp;(World)" class='offre'>Offers & Applications</a>
					<ul class='list'>
						<li><a href='https://localhost/www.blogger-link.com/job-offers/' title="Job offers&nbsp;(World)">Job offers</a></li>
						<li><a href='https://localhost/www.blogger-link.com/training-offers/' title="Internship offers&nbsp;(World)">Internship offers</a></li>
						<li><a href='https://localhost/www.blogger-link.com/job-applications/' title="Job applications&nbsp;(World)">Job applications</a></li>
						<li><a href='https://localhost/www.blogger-link.com/training-applications/' title="Internship applications&nbsp;(World)" class='noborder'>Internship applications</a></li>
					</ul>
				</li>
				<li class='scrollerItem'><a href='https://localhost/www.blogger-link.com/search-results/' title="Search on our engines !" class='recherche' rel='search'>Search on our engines !</a></li>
				<li class='scrollerItem'><a href='https://localhost/www.blogger-link.com/news/' title="News&nbsp;(World)" class='actualites'>News</a></li>				
				<li><a href="https://localhost/www.blogger-link.com/entreprise-space/"  title="Business management" class='gestion'>Business management</a></li>
				<li><a href="https://localhost/entreprise.blogger-link.com/19-blogger-link-ltd" title="Company profile" target='_blank' class='affiche'>Company profile</a></li>
				<li><a href='https://localhost/www.blogger-link.com/site-map/' title="More&nbsp;(World)" class='plus'>More</a></li>
			</ul>
			</nav>
			<div class='clear'></div>
		</div>

<div class='content'>
	<section>
	<nav>
	<ol class='breadcrumb'>
	  <li><a href='https://localhost/www.blogger-link.com' title="{$TXT_HEADER_ACCUEIL}">{$TXT_HEADER_ACCUEIL}</a> &gt;</li>
	  <li><a href='https://localhost/www.blogger-link.com/news/' title="articles & actualit�s">articles & actualit�s</a> &gt;</li>
	  <li class='active'><h1>2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse</h1></li>
	</ol>
	</nav>
	</section>
	<section>
	<div class='txt-web' style="text-align:left;">
					<article>
				<header>
					<p>2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse</p>
				</header>				
				<p>
											<img src='https://localhost/tofs.blogger-link.com/?type_photo=frontoffice-news-article&amp;url_image=https://localhost/tofs.blogger-link.com/original-photo.php?oid=59781370' alt='2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse' />
										<br/><br/>				
					<p class="first" style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	2 EN Plusieurs sites de Renault ont &eacute;t&eacute; perquisitionn&eacute;s la semaine derni&egrave;re dans le cadre de l&#39;enqu&ecirc;te men&eacute;e apr&egrave;s le scandale&nbsp;<a class="yom-entity-link" data-rapid_p="1" href="https://fr.news.yahoo.com/volkswagen/" style="color: rgb(93, 67, 112); text-decoration: none;">Volkswagen</a>, une r&eacute;v&eacute;lation qui a entra&icirc;n&eacute; l&#39;effondrement en Bourse des constructeurs fran&ccedil;ais et l&#39;assurance par le groupe fran&ccedil;ais qu&#39;aucune fraude n&#39;avait &eacute;t&eacute; d&eacute;tect&eacute;e sur ses moteurs diesel.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	A 15H20 (14H20 GMT) Renault perdait 8,87%, apr&egrave;s avoir affich&eacute; &agrave; la mi-journ&eacute;e un recul sup&eacute;rieur &agrave; 20%. Dans son sillage,&nbsp;<a class="yom-entity-link" data-rapid_p="2" href="https://fr.news.yahoo.com/peugeot/" style="color: rgb(93, 67, 112); text-decoration: none;">Peugeot</a>&nbsp;reculait de 2,88% apr&egrave;s avoir frol&eacute; les -9%, ainsi que les &eacute;quipementiers automobiles Faurecia (-2,71%%), et Valeo (-2,69%) dans un march&eacute; en baisse de 1,72%.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Cette chute suivait l&#39;annonce de perquisitions men&eacute;es la semaine derni&egrave;re dans plusieurs sites de Renault - le si&egrave;ge social, le Centre technique Renault de Lardy et le Technocentre de Guyancourt - par la Direction g&eacute;n&eacute;rale de la concurrence, de la consommation et de la r&eacute;pression des fraudes (DGCCRF).</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Ces perquisitions ont &eacute;t&eacute; r&eacute;alis&eacute;es dans le cadre de l&#39;enqu&ecirc;te men&eacute;e par une commission technique ind&eacute;pendante mise en place par le gouvernement fran&ccedil;ais, et charg&eacute;e de v&eacute;rifier que les constructeurs n&#39;ont pas &eacute;quip&eacute; leurs v&eacute;hicules de logiciels &eacute;quivalents &agrave; ceux de Volkswagen.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Une conf&eacute;rence de presse &eacute;tait pr&eacute;vue &agrave; 16H30 ce jeudi au minist&egrave;re de l&#39;Ecologie &agrave; l&#39;issue d&#39;une r&eacute;union de cette commission ind&eacute;pendante.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Renault assure que &quot;la direction g&eacute;n&eacute;rale de l&#39;&eacute;nergie et du climat (DGEC), qui est, au titre du minist&egrave;re de l&#39;Ecologie (...), l&#39;interlocuteur pilote de la Commission technique ind&eacute;pendante, consid&egrave;re que la proc&eacute;dure en cours ne mettrait pas en &eacute;vidence la pr&eacute;sence d&#39;un logiciel truqueur &eacute;quipant les v&eacute;hicules Renault&quot;.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	&quot;En parall&egrave;le, la DGCCRF a d&eacute;cid&eacute; de faire proc&eacute;der &agrave; un compl&eacute;ment d&#39;investigation sur pi&egrave;ce et sur site, qui a vocation &agrave; valider d&eacute;finitivement les premiers &eacute;l&eacute;ments d&#39;analyse r&eacute;alis&eacute;s par la Commission technique ind&eacute;pendante&quot;, ajoute le groupe, qui assure &quot;(coop&eacute;rer) pleinement aux travaux&quot; de cette commission.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	La CGT du Centre technique de Renault Lardy, qui avait fait &eacute;tat dans la matin&eacute;e de ces perquisitions, confirm&eacute;es ensuite par la direction, a soulign&eacute; que les enqu&ecirc;teurs &quot;ont r&eacute;cup&eacute;r&eacute; les PC de plusieurs directeurs&quot;.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	<span style="font-size: 14.04px; line-height: 22.464px;">Apr&egrave;s le scandale Volkswagen, Renault a annonc&eacute; en d&eacute;cembre un plan d&#39;investissements de 50 millions d&#39;euros pour r&eacute;duire l&#39;&eacute;cart entre les &eacute;missions polluantes de ses voitures en conditions d&#39;homologation et en situation r&eacute;elle.</span></p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	&nbsp;</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	- Commission technique r&eacute;unie jeudi -</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Le constructeur PSA Peugeot&nbsp;<a class="yom-entity-link" data-rapid_p="4" href="https://fr.news.yahoo.com/citroen/" style="color: rgb(93, 67, 112); text-decoration: none;">Citro&euml;n</a>, dont le titre a p&acirc;tit par ricochet de la chute de Renault, a rapidement envoy&eacute; un communiqu&eacute;, et pr&eacute;cis&eacute; &quot;ne pas avoir fait l&#39;objet d&#39;une perquisition de la DGCCRF&quot;.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	&quot;Les r&eacute;sultats des tests r&eacute;alis&eacute;s par la commission technique&quot; pr&eacute;sid&eacute;e par la ministre de l&#39;Ecologie<a class="yom-entity-link" data-rapid_p="5" href="https://fr.news.yahoo.com/segolene-royal/" style="color: rgb(93, 67, 112); text-decoration: none;">S&eacute;gol&egrave;ne Royal</a>&nbsp;&quot;nous ont &eacute;t&eacute; communiqu&eacute;s et attestent de l&#39;absence de toute anomalie&quot;, ajoute le groupe.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	La commission technique ind&eacute;pendante charg&eacute;e de r&eacute;aliser ces tests pour le compte du gouvernement afin de d&eacute;tecter d&#39;&eacute;ventuelles fraudes &agrave; la pollution sur des voitures fran&ccedil;aises &eacute;tait, jeudi en d&eacute;but d&#39;apr&egrave;s-midi, en cours de r&eacute;union au minist&egrave;re de l&#39;Energie, selon des sources concordantes.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Les r&eacute;sultats de ces tests, r&eacute;alis&eacute;s par le laboratoire Utac-Ceram depuis octobre dernier sur 100 voitures, y seront pr&eacute;sent&eacute;s, selon les ONG environnementales F&eacute;d&eacute;ration nature environnement (FNE) et R&eacute;seau action climat, qui ont des repr&eacute;sentants au sein de cette commission.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Une conf&eacute;rence de presse est pr&eacute;vue ce jeudi &agrave; 16H30 au minist&egrave;re &agrave; l&#39;issue de la r&eacute;union.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Selon France Inter qui ne cite pas de sources, les r&eacute;sultats de Renault seraient particuli&egrave;rement mauvais.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	&quot;Pour PSA, l&#39;&eacute;cart entre les &eacute;mission lors des tests en laboratoire et sur route est classique, deux fois plus en conditions r&eacute;elles. Pour Volkswagen, c&#39;est trois ou quatre fois plus. Mais pour Renault, les r&eacute;sultats sont tr&egrave;s mauvais, bien au-dessus des autres constructeurs&quot;, croit savoir la radio.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	La commission technique est compos&eacute;e de chercheurs, d&#39;associations de d&eacute;fense des consommateurs et de l&#39;environnement et d&#39;organismes gouvernementaux.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	Le num&eacute;ro deux automobile mondial Volkswagen avait &eacute;quip&eacute; 11 millions de v&eacute;hicules diesel dans le monde d&#39;un logiciel sp&eacute;cifique pour d&eacute;jouer les normes antipollution, mais se d&eacute;fend de tout &quot;mensonge&quot; dans cette affaire.</p>
<p style="margin: 11px 0px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Georgia, Times, 'Times New Roman', serif; font-size: 14.04px; line-height: 22.464px;">
	<span style="color: rgb(125, 125, 125); font-size: 12.09px; line-height: 26.598px;">Par&nbsp;</span><span class="fn" style="color: rgb(125, 125, 125); font-size: 12.09px; line-height: 26.598px;">Julie CHABANAS et Sylvie HUSSON</span></p>

				</p>
			</article>
			<aside>				
														<br/><br/>		
					<label for='url-career-news' title='https://fr.news.yahoo.com'><b>Source de l'actualite : </b></label>
					<a href='https://fr.news.yahoo.com/bourse-renault-plonge-10-après-lannonce-perquisitions-110910766.html' rel='nofollow' target='_blank'>https://fr.news.yahoo.com/bourse-renault-plonge-10-après-lannonce-perquisitions-110910766.html</a>
					<br/>
					<input type='text' value='https://fr.news.yahoo.com/bourse-renault-plonge-10-après-lannonce-perquisitions-110910766.html' id='url-career-news' size='150' />	
							</aside>
					
				<div class='clear'><br/></div>
		
<aside>
<div class="a2a_kit a2a_kit_size_32 a2a_default_style">							
	<a class="a2a_button_google_plus"></a>
	<a class="a2a_button_facebook"></a>
	<a class="a2a_button_twitter"></a>
	<a class="a2a_button_whatsapp"></a>
	<a class="a2a_button_linkedin"></a>
	<a class="a2a_button_viadeo"></a>
	<a class="a2a_button_tumblr"></a>
	<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
</div>
</aside>						
		<div class='clear'><br/><img src='https://localhost/career-news.blogger-link.com/public/media/images/logo-icon.png' alt='blogger-link.com logo' title='blogger-link.com logo' /><br/><br/></div>
		
<section>
<div class='blocPubRight'><img src='https://localhost/career-news.blogger-link.com/public/media/images/pub.png' alt="https://localhost/career-news.blogger-link.com/public/media/images/pub.png" /></div>
</section>		
	</div>			
	</section>
	<div class='clear'></div>
</div>
</div>
</section>

<section>
<div class='remarquecookie'>
	<div class='container'>
		<div class='row'>
			<a class='ico-close' title="Close, and remind me later">X</a>
			<h4>Note about Cookies & Terms and Conditions</h4>
			<p>Continuing your visit to this site, you accept the use of cookies to provide you with content and services adapted and achieving visits statistics. <a href='https://localhost/www.blogger-link.com/cookies/'>Learn more</a> about cookies.<br/><a href='https://localhost/www.blogger-link.com/terms-of-use/'>See</a> our terms and conditions</p>
		</div>
	</div>	
</div>
</section>

<footer>

	<div id='blogger_footer'><h4>2 EN Diesel: Renault perquisitionné par la répression des fraudes, chute en Bourse. On Blogger-Link.</h4></div>

	<div class='blocBlanc'>
	<div class='annuaire'>
		<span class='col-xs-12 col-sm-5'>Membership directory of blogger-link.com (first name or last name) :</span>
		<ul class='col-xs-11 col-sm-5'><li><a href='https://localhost/www.blogger-link.com/members/bloggers-a/' title='a'>A</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-b/' title='b'>B</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-c/' title='c'>C</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-d/' title='d'>D</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-e/' title='e'>E</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-f/' title='f'>F</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-g/' title='g'>G</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-h/' title='h'>H</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-i/' title='i'>I</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-j/' title='j'>J</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-k/' title='k'>K</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-l/' title='l'>L</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-m/' title='m'>M</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-n/' title='n'>N</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-o/' title='o'>O</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-p/' title='p'>P</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-q/' title='q'>Q</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-r/' title='r'>R</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-s/' title='s'>S</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-t/' title='t'>T</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-u/' title='u'>U</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-v/' title='v'>V</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-w/' title='w'>W</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-x/' title='x'>X</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-y/' title='y'>Y</a></li><li><a href='https://localhost/www.blogger-link.com/members/bloggers-z/' title='z'>Z</a></li></ul>
		<span class='col-xs-1'>(World)</span>
		<div class='clear'></div>
	</div>
	<div class='annuaire'>
		<form class='formRecherche' method='POST' action='https://localhost/www.blogger-link.com/members/'>
			<div class='blocForm libelle'><label>Find a person :</label></div>
			<div class='blocForm zoneTexte firstChamps'>
				<input type='text' class='champTexte' name='prenom_recherche_membre' placeholder='First name' value='' />
				<!-- autocomplete
				<ul class='autoComplete'><li>tes<b>pi</b> teste</li><li><b>pi</b>teste teste</li><li>teste teste<b>pi</b></li></ul>
				 -->
			</div>
			<div class='blocForm zoneTexte'>
				<input type='text' class='champTexte' name='nom_recherche_membre' placeholder='Last name' value='' />
				<!-- autocomplete
				<ul class='autoComplete'><li>tes<b>pi</b> teste</li><li><b>pi</b>teste teste</li><li>teste teste<b>pi</b></li></ul>
				 -->
			</div>
			<div class='blocForm btnForm'><input type='submit' class='btnRecherche' name='submit' value='Search' title='Search' /></div>
			<div class='clear'></div>
		</form>
	</div>
</div>
<div class='clear'></div>

<div class='bgFooter'>
	<div class='footer'>
		<span class='img-ico-top' title="Go to the top of the page"></span>			
		<ul class='col-xs-12 col-sm-3 blocFooterLeft'>
			<li><a href='https://localhost/www.blogger-link.com/blogger-model/' title="Blog-cv model&nbsp;(World)">Blog-cv model</a></li>
			<li><a href='https://localhost/www.blogger-link.com/entreprise-model/' title="Business listing model&nbsp;(World)">Business listing model</a></li>
			<li><a href='https://localhost/www.blogger-link.com/terms-of-use/' title="Terms&nbsp;(World)">Terms</a></li>
			<li><a href='https://localhost/www.blogger-link.com/privacy-policy/' title="Data protection&nbsp;(World)">Data protection</a></li>
			<li><a href='https://localhost/www.blogger-link.com/cookies/' title="Cookies&nbsp;(World)">Cookies</a></li>
		</ul>		
		<ul class='col-xs-12 col-sm-3 blocFooterMiddle'>
			<li><a href='https://localhost/www.blogger-link.com/media/' title="The press speaks&nbsp;(World)">The press speaks</a></li>
			<li><a href='https://localhost/www.blogger-link.com/contact/' title="Contact&nbsp;(World)">Contact</a></li>
			<li><a href='https://localhost/www.blogger-link.com/our-partners/' title="Our partners&nbsp;(World)">Our partners</a></li>
			<li><a href='https://localhost/www.blogger-link.com/about-us/' title="Who are we ?&nbsp;(World)">Who are we ?</a></li>
			<li><a href='https://localhost/www.blogger-link.com/about-the-founder/' title="About the founder&nbsp;(World)">About the founder</a></li>
			<li><a href='https://localhost/www.blogger-link.com/members/' title="Members bloggers&nbsp;(World)">Members bloggers</a></li>			
		</ul>		
		<ul class='col-xs-12 col-sm-3 blocFooterRight'>
			<li><a href='https://localhost/www.blogger-link.com/site-map/' title="Sitemap&nbsp;(World)">Sitemap</a></li>
			<li><a href='https://localhost/www.blogger-link.com/send-us-a-comment/' title="Send us a comment&nbsp;(World)">Send us a comment</a></li>
			<li><a href='https://localhost/www.blogger-link.com/blogger-testimony/' title="Blogger testimony&nbsp;(World)">Blogger testimony</a></li>
			<li><a href='https://localhost/www.blogger-link.com/entreprise-testimony/' title="Entreprise testimony&nbsp;(World)">Entreprise testimony</a></li>
			<li><a href='https://localhost/www.blogger-link.com/newsletter/' title="Newsletter&nbsp;(World)">Newsletter</a></li>
			<li><a href='https://localhost/www.blogger-link.com/delete-my-account/' title="Delete your account&nbsp;(World)">Delete your account</a></li>
		</ul>
		<a href='javascript:void(0);' title="blogger-link.com is responsive, adaptive / All resolutions" class='groupe col-xs-12 col-sm-3'><img src='https://localhost/career-news.blogger-link.com/public/media/images/groupe.png' alt="blogger-link.com is responsive, adaptive / All resolutions" class='img-responsive' /></a>
		<span>Loading time : 5 Sec</span>
		<div class='clear'></div>
	</div>
	<div class='blocBasFooter'>
		<div class='bas-footer'>
			<div class='footerLeft col-xs-12 col-sm-6'>
				<img src='https://localhost/career-news.blogger-link.com/public/media/images/slogan.png' alt="blogger-link.com logo" class='slogan' />
				<a href='https://localhost/www.blogger-link.com' title="Blogger-Link.com &copy; 2016">Blogger-Link.com &copy; 2016</a>
			</div>
			<div class='col-xs-12 col-sm-6'>
				<ul class='listFooter'>
					<li><a href='https://localhost/www.blogger-link.com/xml-feed/' title="Xml feed&nbsp;(World)"><img src='https://localhost/career-news.blogger-link.com/public/media/images/xml.png' alt="Xml feed" /></a></li>
					<li><a href='https://localhost/www.blogger-link.com/rss-feed/' title="Rss feed&nbsp;(World)"><img src='https://localhost/career-news.blogger-link.com/public/media/images/rss.png' alt="Rss feed" /></a></li>
					<li><a href='javascript:void(0);' title="Follow us&nbsp;(World)">Follow us</a></li>
					<li><a href='' title="blogger-link.com on googlePlus" target='_blank'><img src='https://localhost/career-news.blogger-link.com/public/media/images/gplus.png' alt="blogger-link.com on googlePlus" /></a></li>
					<li><a href='https://www.facebook.com/' title="blogger-link.com on facebook" target='_blank'><img src='https://localhost/career-news.blogger-link.com/public/media/images/face.png' alt="blogger-link.com on facebook" /></a></li>
					<li><a href='https://www.twitter.com/' title="blogger-link.com on twitter" target='_blank'><img src='https://localhost/career-news.blogger-link.com/public/media/images/twitter.png' alt="blogger-link.com on twitter" /></a></li>
					<li><a href='javascript:void(0);' title="blogger-link.com"><img src='https://localhost/career-news.blogger-link.com/public/media/images/blogger-link.png' alt="blogger-link.com" /></a></li>
				</ul>
			</div>
			<div class='clear'></div>
		</div>
	</div>
</div>

<script type='text/javascript'>var _ROOT_URL='https://localhost/career-news.blogger-link.com';</script><script type='text/javascript'>var _BLOGGER_SPACE_URL='_BLOGGER_SPACE_URL';</script><script type='text/javascript'>var _ENTREPRISE_SPACE_URL='_ENTREPRISE_SPACE_URL';</script><script type='text/javascript'>var _PHOTO_URL='https://localhost/tofs.blogger-link.com/';</script><script type='text/javascript'>var _INCLUDE_AJAX_URL='https://localhost/career-news.blogger-link.com/private/include-ajax/';</script><script type='text/javascript'>var _IMAGES_URL='https://localhost/career-news.blogger-link.com/public/media/images/';</script><script type='text/javascript'>var _ID_LANGUAGE='2';</script><script type='text/javascript' src='https://localhost/career-news.blogger-link.com/public/media/cache_combo_handler/combo_handler_js.php?js_files_gzip_deflate=D:/wamp/www/career-news.blogger-link.com/public/media/js/jquery_and_requires/jquery-2.1.4.min.js|D:/wamp/www/career-news.blogger-link.com/public/media/js/jquery_and_requires/jquery.mCustomScrollbar.concat.min.js|D:/wamp/www/career-news.blogger-link.com/public/media/js/jquery_and_requires/jquery.flexslider.js|D:/wamp/www/career-news.blogger-link.com/public/media/js/jquery_and_requires/scripts.js|D:/wamp/www/career-news.blogger-link.com/public/media/js/article.js'></script>		

<script type="text/javascript" src="//static.addtoany.com/menu/page.js"></script>

</footer>
</body>
</html><?php }
}
?>
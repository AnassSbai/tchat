var scriptUrl_1 = _INCLUDE_AJAX_URL + 'refresh_chat.php';
var scriptUrl_2 = _INCLUDE_AJAX_URL + 'new_message.php';
var msgError = '<img src=\''+_ROOT_URL+'/view/media/images/icon-warning.png\' /> >> CONNEXION FAILED <<';

/**
 * Fonction permettant de mettre a jour le contenu du chat 
 * 
 * @param id_selected_user
 * @return
 */
function refresh_chat(id_selected_user){
	$(document).ready(function(){
		//Enlever les styles css des utilisateurs
		$('.content #user a').css({'border' : '', 'padding' : '0px'});
		//Attribuer les styles css des utilisateurs
		$('#selected_'+id_selected_user).css({'border' : '2px solid red', 'padding' : '5px'});
		//Traitement ajax pour rafrichir le chat		
		$.ajax({
			type: 'POST',
			url: scriptUrl_1,
			data: 'id_selected_user='+id_selected_user,
			success: function(msg){
				//Afichage traitement PHP
				$('.right_chat').html(msg);	
				//Envoie nouveau message
				$('#send_message').click(function(){					
					sendNewMessage_chat(id_selected_user);					
				});				
			},
			error: function(msg){
			  	$('.right_chat').html(msgError);
			}
		});
	});
}

/**
 * Fonction permettant d'ajouter un nouveau message, et rafrichir le chat
 * 
 * @param id_selected_user
 * @return
 */
function sendNewMessage_chat(id_selected_user){
	var message = encodeURIComponent($('#new_message').val());
	if(message != ''){
		$(document).ready(function(){
			//Traitement ajax pour ajouter le message		
			$.ajax({
				type: 'POST',
				url: scriptUrl_2,
				data: 'nouveau_message='+message+'&id_selected_user='+id_selected_user,
				success: function(msg){
					//Rafrichissement du chat
					refresh_chat(id_selected_user);	
				},
				error: function(msg){
				  	$('.right_chat').html(msgError);
				}
			});
		});	
	}
}
<?php
include rtrim(str_replace('\\', '/', __DIR__), '/').'/'.'app/config/params.inc.php';
if( (!isset($_SESSION['id_utilisateur'])) && (empty($_SESSION['id_utilisateur'])) ):
	$access = new UserController();
	if(isset($_POST)):
		$access = $access->isAuthorized_UserAction($_POST['login'], $_POST['password']);
		if(!$access):
			$error = '>> utilisateur inexistant <<';
		else:
			//Assignation de valeurs de session
			$_SESSION['id_utilisateur'] = $access->id_utilisateur;
			$_SESSION['prenom_utilisateur'] = $access->prenom_utilisateur;
			$_SESSION['nom_utilisateur'] = $access->nom_utilisateur;
			//Redirection
			$router = new RoutingTchat();
			$router->generateUrl_Redirect(_ROOT_URL.'chat.php');
		endif;
	endif;
	$smartyTPL = new SmartyTchat();
	$smartyTPL->assign('error', $error);
	$smartyTPL->display('index.tpl');
else:
	//Redirection
	$router = new RoutingTchat();
	$router->generateUrl_Redirect(_ROOT_URL.'chat.php');
endif;
?>
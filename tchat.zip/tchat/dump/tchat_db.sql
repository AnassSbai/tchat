SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `tchat_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id_message` int(11) NOT NULL AUTO_INCREMENT,
  `contenu_message` text NOT NULL,
  `date_message` timestamp NOT NULL,
  `id_utilisateur_message_from` int(11) NOT NULL,
  `id_utilisateur_message_to` int(11) NOT NULL,
  PRIMARY KEY (`id_message`),
  KEY `message_ibfk_1` (`id_utilisateur_message_from`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `message`
--

INSERT INTO `message` (`id_message`, `contenu_message`, `date_message`, `id_utilisateur_message_from`, `id_utilisateur_message_to`) VALUES
(1, 'Bonjour Anass.', '2018-03-25 11:34:15', 2, 1),
(2, 'Bonjour Samar.', '2018-03-25 11:34:32', 1, 2),
(3, 'Est ce que vous Ãªtes disponible immÃ©diatement ?', '2018-03-25 11:35:32', 2, 1),
(4, 'Oui, et prÃªt pour passer un entretien physique avec votre client', '2018-03-25 11:36:04', 1, 2),
(6, 'Ok en se voit demain', '2018-03-25 11:39:31', 2, 1),
(7, 'Ã§a marche on fait comme Ã§a', '2018-03-25 11:40:04', 1, 2),
(8, 'Bonjour Marie. Ã§a va ?', '2018-03-25 11:41:44', 2, 4),
(9, 'Salut Samar. Oui tout va bien Merci', '2018-03-25 11:42:33', 4, 2),
(10, 'Salut Anass', '2018-03-25 11:47:07', 3, 1),
(11, 'Salut mon ami. Comment vas tu ?', '2018-03-25 11:47:58', 1, 3);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `prenom_utilisateur` varchar(100) NOT NULL,
  `nom_utilisateur` varchar(100) NOT NULL,
  `pseudo_utilisateur` varchar(100) NOT NULL,
  `password_utilisateur` varchar(500) NOT NULL,
  PRIMARY KEY (`id_utilisateur`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `prenom_utilisateur`, `nom_utilisateur`, `pseudo_utilisateur`, `password_utilisateur`) VALUES
(1, 'Anass', 'SBAI SASSI', 'asbai', 'e10adc3949ba59abbe56e057f20f883e'),
(2, 'Samar', 'KHIARI', 'samar', 'c33367701511b4f6020ec61ded352059'),
(3, 'Jean-Jack', 'Michael', 'micha', 'e10adc3949ba59abbe56e057f20f883e'),
(4, 'Maria', 'Clair', 'marie', 'c33367701511b4f6020ec61ded352059');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`id_utilisateur_message_from`) REFERENCES `utilisateur` (`id_utilisateur`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

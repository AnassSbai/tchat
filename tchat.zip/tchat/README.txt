(*)
Requirement ,
	PHP version    : <= PHP 5.5
	APACHE version : Apache 2.4

(**)
How to install ,
	- Copy the "tchat" folder under your web server root {{ => $_SERVER['DOCUMENT_ROOT'] }}.
	- Create "tchat_db" database in your mysql server.
	- Launch "dump/tchat_db.sql" by "phpmyadmin" project.

(***)  
How to use ~ Example ,
	- This is the liste of users
	  login:     password:
	  asbai      123456
	  micha      123456
	  samar      654321
	  marie      654321
	- 
	Then,
	 * For one machine : use 2 different browsers (with one user each)
	 * For 2 different machines : change the IP of the database, 
	   and 
	   Choose "Put Online" with your wamp server.

Enjoy !
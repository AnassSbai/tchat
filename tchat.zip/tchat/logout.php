<?php
include rtrim(str_replace('\\', '/', __DIR__), '/').'/'.'app/config/params.inc.php';
//Desenregistrement de toutes les variables de session courantes.
session_unset();
//Suppression de l'ID de la session.
session_destroy();
//Redirection
$router = new RoutingTchat();
$router->generateUrl_Redirect(_ROOT_URL);
?>
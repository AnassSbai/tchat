<?php 
include rtrim(str_replace('\\', '/', __DIR__), '/').'/'.'app/config/params.inc.php';
$smartyTPL = new SmartyTchat();
$smartyTPL->display('error-404.tpl');
?>
<?php
include rtrim(str_replace('\\', '/', __DIR__), '/').'/'.'app/config/params.inc.php';
if( (isset($_SESSION['id_utilisateur'])) && (!empty($_SESSION['id_utilisateur'])) ):
	$chat = new DefaultTchatController();
	$users_list = $chat->getList_UsersAction($_SESSION['id_utilisateur']);	
	$smartyTPL = new SmartyTchat();
	$smartyTPL->assign('users_list', $users_list);
	$smartyTPL->display('chat.tpl');
else:
	//Redirection
	$router = new RoutingTchat();
	$router->generateUrl_Redirect(_ROOT_URL);
endif
?>